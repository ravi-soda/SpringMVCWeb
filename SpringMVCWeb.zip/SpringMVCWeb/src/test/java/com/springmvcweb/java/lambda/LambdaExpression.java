package com.springmvcweb.java.lambda;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

interface Executer {
	void execute();
}

class Runner {
	
	void run(Executer e){
		System.out.println("Executing execute method.");
		e.execute();
	}
}

public class LambdaExpression {
	public static void main(String[] args) {
		Runner runner = new Runner();
		runner.run(new Executer() {
			public void execute() {
				System.out.println("Hi there");
			}
		});
		
		runner.run(() -> System.out.println("Hi Lambda"));
		System.out.println("====================");
		System.out.println("sort elements");
		LambdaExpression le = new LambdaExpression();
		le.sortCollection();
	}
	
	private void sortCollection(){
		List<String> names = Arrays.asList("harry", "danny", "mickey");
		List<String> result = names.stream().filter(name -> name.startsWith("m")).collect(Collectors.toList());
		result.forEach(p -> System.out.println(p));
	}
}
