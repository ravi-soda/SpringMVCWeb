package com.springweb.sample;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/restful")
public class SampleRestController {

  @RequestMapping(method=RequestMethod.GET, value="/hello" )
  public String sayHello(){
    return "Hello restful";
  }
}
